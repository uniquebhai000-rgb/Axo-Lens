# AXO LENS — Capture Beyond Limits.

## Get the APK (no Android Studio needed)
1. Create a GitHub repo and upload ALL files of this project (keep the `.github` folder). Push to `main`.
2. Repo -> **Actions** -> **Build APK** -> wait for the green check.
3. Open the run -> **Artifacts** -> download `axo-lens-debug-apk` -> unzip -> install the APK on your phone.
If the build fails, copy the error from the Actions log and send it to Claude to fix.

## Checklist
- [x] Phase 1: foundation, CameraX preview, photo capture (MediaStore), tap-focus, zoom, EV, flash, front/back, device analyzer + performance profiles, theme, icon, CI
- [ ] Phase 2: modes, timer, grid/level, burst, volume shutter, settings (DataStore)
- [ ] Phase 3: video recording
- [ ] Phase 4: AI engine (denoise, multi-frame HDR/night, super resolution via LiteRT, OpenCV)
- [ ] Phase 5: gallery, editor, Photo Doctor, portrait
- [ ] Phase 6: cloud interface, Room, DI, tests, release signing
