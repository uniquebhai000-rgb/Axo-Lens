@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.axolens.app.gallery

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.axolens.app.MediaItem
import com.axolens.app.MediaRepo
import com.axolens.app.Prefs
import com.axolens.app.ui.AxoYellow
import java.util.Date
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun day(ctx: Context, sec: Long): String = DateFormat.getMediumDateFormat(ctx).format(Date(sec * 1000))

@Composable
fun GalleryScreen(onEdit: (Uri) -> Unit, onDoctor: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf(0) }
    var viewer by remember { mutableStateOf<Int?>(null) }
    val favs = Prefs.favorites.value

    fun reload() { scope.launch { items = withContext(Dispatchers.IO) { MediaRepo.load(ctx) }; loaded = true } }
    LaunchedEffect(Unit) { reload() }

    val shown = items.filter { !it.name.contains("_orig") }.filter {
        when (filter) { 1 -> !it.isVideo; 2 -> it.isVideo; 3 -> favs.contains(it.uri.toString()); else -> true }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Text("Gallery", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Photos", "Videos", "Favorites").forEachIndexed { i, n ->
                Text(n, color = if (filter == i) Color.Black else Color.White, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (filter == i) AxoYellow else Color(0xFF2A2A2E))
                        .clickable { filter = i }.padding(horizontal = 14.dp, vertical = 6.dp))
            }
        }
        if (loaded && shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (filter == 3) "No favorites yet." else "No photos yet.\nTake one with the camera.",
                    color = Color.Gray)
            }
        } else {
            val groups = shown.groupBy { day(ctx, it.dateSec) }
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                groups.forEach { (d, list) ->
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(d, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(12.dp, 10.dp, 12.dp, 4.dp))
                    }
                    items(list) { m ->
                        Box(Modifier.aspectRatio(1f).clickable { viewer = shown.indexOf(m) }) {
                            AsyncImage(
                                ImageRequest.Builder(ctx).data(m.uri).size(300, 300).build(), m.name,
                                Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (m.name.startsWith("AXO_HD")) Text("HD", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
                                    .background(AxoYellow, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp))
                            if (m.isVideo) Icon(Icons.Default.PlayArrow, "Video", tint = Color.White,
                                modifier = Modifier.align(Alignment.Center).size(32.dp))
                            if (favs.contains(m.uri.toString())) Icon(Icons.Default.Favorite, "Favorite",
                                tint = Color.Red, modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).size(16.dp))
                        }
                    }
                }
            }
        }
    }

    val v = viewer
    if (v != null && v < shown.size) {
        Viewer(shown, items, v, onClose = { viewer = null }, onDeleted = { viewer = null; reload() }, onEdit = {
            viewer = null; onEdit(it)
        }, onDoctor = { viewer = null; onDoctor(it) })
    }
}

@Composable
private fun Viewer(items: List<MediaItem>, all: List<MediaItem>, start: Int, onClose: () -> Unit, onDeleted: () -> Unit, onEdit: (Uri) -> Unit, onDoctor: (Uri) -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = start) { items.size }
    var zoomed by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    BackHandler(onBack = onClose)
    val cur = items[pager.currentPage.coerceIn(0, items.size - 1)]
    val fav = Prefs.favorites.value.contains(cur.uri.toString())
    var showOrig by remember { mutableStateOf(false) }
    fun origOf(m: MediaItem): MediaItem? = all.firstOrNull { it.name == m.name.removeSuffix(".jpg") + "_orig.jpg" }
    val curOrig = origOf(cur)
    val isHd = cur.name.startsWith("AXO_HD")

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize(), userScrollEnabled = !zoomed) { page ->
            val pm = items[page]
            ViewerPage(if (showOrig) (origOf(pm) ?: pm) else pm) { zoomed = it }
        }
        IconButton(onClick = onClose, Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
        }
        if (isHd) Text(if (showOrig && curOrig != null) "ORIGINAL" else "AXO HD ENHANCED", color = Color.Black, fontSize = 11.sp,
            fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                .background(if (showOrig && curOrig != null) Color.White else AxoYellow, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000)).padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly) {
            IconButton(onClick = { Prefs.toggleFav(cur.uri.toString()) }) {
                Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorite",
                    tint = if (fav) Color.Red else Color.White)
            }
            IconButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).setType(if (cur.isVideo) "video/*" else "image/*")
                    .putExtra(Intent.EXTRA_STREAM, cur.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                ctx.startActivity(Intent.createChooser(i, "Share"))
            }) { Icon(Icons.Default.Share, "Share", tint = Color.White) }
            if (curOrig != null) TextButton(onClick = { showOrig = !showOrig }) {
                Text(if (showOrig) "Show enhanced" else "Show original", color = AxoYellow)
            }
            if (!cur.isVideo) IconButton(onClick = { onDoctor(cur.uri) }) { Icon(Icons.Default.MedicalServices, "Photo Doctor", tint = Color.White) }
            if (!cur.isVideo) IconButton(onClick = { onEdit(cur.uri) }) { Icon(Icons.Default.Edit, "Edit", tint = Color.White) }
            IconButton(onClick = { info = true }) { Icon(Icons.Default.Info, "Info", tint = Color.White) }
            IconButton(onClick = { confirm = true }) { Icon(Icons.Default.Delete, "Delete", tint = Color.White) }
        }
    }
    if (info) AlertDialog(onDismissRequest = { info = false }, confirmButton = { TextButton(onClick = { info = false }) { Text("OK") } },
        title = { Text(cur.name) }, text = {
            Text("Size: ${Formatter.formatFileSize(ctx, cur.size)}\nResolution: ${cur.width} x ${cur.height}" +
                (if (cur.isVideo) "\nDuration: ${cur.durationMs / 1000}s" else "") +
                "\nAXO enhanced: ${if (isHd) "yes" else "no"}\nDate: ${day(ctx, cur.dateSec)}\nFolder: Pictures or Movies / AXO LENS")
        })
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("Delete permanently?") }, text = { Text("This cannot be undone.") },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                try { ctx.contentResolver.delete(cur.uri, null, null); onDeleted() }
                catch (e: Exception) { Toast.makeText(ctx, "Could not delete this file", Toast.LENGTH_SHORT).show() }
            }) { Text("Delete") }
        }, dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}

@Composable
private fun ViewerPage(m: MediaItem, onZoom: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        awaitEachGesture {
            awaitFirstDown(requireUnconsumed = false)
            do {
                val ev = awaitPointerEvent()
                val n = ev.changes.count { it.pressed }
                if (n >= 2 || scale > 1f) {
                    scale = (scale * ev.calculateZoom()).coerceIn(1f, 6f)
                    off = if (scale <= 1f) Offset.Zero else off + ev.calculatePan()
                    onZoom(scale > 1.01f)
                    ev.changes.forEach { if (it.positionChanged()) it.consume() }
                }
            } while (ev.changes.any { it.pressed })
        }
    }, contentAlignment = Alignment.Center) {
        AsyncImage(
            ImageRequest.Builder(ctx).data(m.uri).size(2400, 2400).build(), m.name,
            Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y),
            contentScale = ContentScale.Fit)
        if (m.isVideo) IconButton(onClick = {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(m.uri, "video/*")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        }, Modifier.size(80.dp).background(Color(0x88000000), RoundedCornerShape(50))) {
            Icon(Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(48.dp))
        }
    }
}
