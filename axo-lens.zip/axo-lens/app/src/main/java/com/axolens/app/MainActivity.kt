package com.axolens.app

import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import coil.Coil
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.axolens.app.camera.CameraScreen
import com.axolens.app.device.DeviceAnalyzer
import com.axolens.app.device.PerformanceProfile
import com.axolens.app.gallery.GalleryScreen
import com.axolens.app.settings.SettingsScreen
import com.axolens.app.studio.DoctorScreen
import com.axolens.app.studio.EditorScreen
import com.axolens.app.studio.StudioScreen
import com.axolens.app.ui.AxoTheme
import com.axolens.app.ui.AxoYellow

private enum class Tab { CAMERA, GALLERY, STUDIO, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        Coil.setImageLoader(ImageLoader.Builder(this).components { add(VideoFrameDecoder.Factory()) }.build())
        setContent { AxoTheme { AxoApp() } }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) && ShutterBus.action != null) {
            if (event?.repeatCount == 0) ShutterBus.action?.invoke()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
private fun AxoApp() {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(Tab.CAMERA) }
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var doctorUri by remember { mutableStateOf<Uri?>(null) }
    val profile = remember {
        runCatching { PerformanceProfile.recommend(DeviceAnalyzer.analyze(ctx)) }.getOrDefault(PerformanceProfile.BALANCED)
    }
    BackHandler(enabled = tab != Tab.CAMERA && editorUri == null && doctorUri == null) { tab = Tab.CAMERA }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Scaffold(
            containerColor = Color.Black,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (tab != Tab.CAMERA) NavigationBar(containerColor = Color(0xFF0B0B0D)) {
                    listOf(
                        Triple(Tab.CAMERA, "Camera", Icons.Default.CameraAlt),
                        Triple(Tab.GALLERY, "Gallery", Icons.Default.PhotoLibrary),
                        Triple(Tab.STUDIO, "AI Studio", Icons.Default.AutoAwesome),
                        Triple(Tab.SETTINGS, "Settings", Icons.Default.Settings),
                    ).forEach { (t, label, icon) ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Icon(icon, label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black, indicatorColor = AxoYellow,
                                selectedTextColor = AxoYellow, unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray),
                        )
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    Tab.CAMERA -> CameraScreen(profile,
                        onGallery = { tab = Tab.GALLERY }, onSettings = { tab = Tab.SETTINGS }, onStudio = { tab = Tab.STUDIO })
                    Tab.GALLERY -> GalleryScreen(onEdit = { editorUri = it }, onDoctor = { doctorUri = it })
                    Tab.STUDIO -> StudioScreen(onDoctor = { doctorUri = it }, onEditor = { editorUri = it })
                    Tab.SETTINGS -> SettingsScreen(profile)
                }
            }
        }
        doctorUri?.let { u -> DoctorScreen(u, onEdit = { doctorUri = null; editorUri = it }, onClose = { doctorUri = null }) }
        editorUri?.let { u -> EditorScreen(u) { editorUri = null } }
    }
}
