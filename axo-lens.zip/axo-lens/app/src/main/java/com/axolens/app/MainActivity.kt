package com.axolens.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.axolens.app.camera.CameraScreen
import com.axolens.app.device.DeviceAnalyzer
import com.axolens.app.device.PerformanceProfile
import com.axolens.app.ui.AxoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AxoTheme {
                val ctx = LocalContext.current
                val profile = remember {
                    runCatching { PerformanceProfile.recommend(DeviceAnalyzer.analyze(ctx)) }
                        .getOrDefault(PerformanceProfile.BALANCED)
                }
                CameraScreen(profile)
            }
        }
    }
}
