package com.axolens.app.device

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics as CC
import android.hardware.camera2.CameraManager
import android.os.Build

data class CameraSummary(
    val id: String, val facing: String, val hasFlash: Boolean, val hasAutofocus: Boolean,
    val supportsRaw: Boolean, val maxJpegMp: Float, val fpsRanges: List<String>, val videoStabilization: Boolean,
)

data class DeviceReport(
    val cameras: List<CameraSummary>, val totalRamMb: Long, val availRamMb: Long,
    val cpuCores: Int, val lowRam: Boolean, val sdk: Int,
)

/** Quality is always prioritised; profiles only trade latency/battery. */
enum class PerformanceProfile(val label: String, val jpegQuality: Int, val maxQuality: Boolean) {
    BALANCED("Balanced", 95, true),
    HIGH_QUALITY("High Quality", 100, true),
    BATTERY_SAVER("Battery Saver", 90, false);

    companion object {
        fun recommend(r: DeviceReport) = if (r.lowRam) BALANCED else HIGH_QUALITY
    }
}

object DeviceAnalyzer {
    fun analyze(ctx: Context): DeviceReport {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cams = cm.cameraIdList.mapNotNull { id ->
            runCatching {
                val c = cm.getCameraCharacteristics(id)
                val map = c.get(CC.SCALER_STREAM_CONFIGURATION_MAP)
                val best = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
                CameraSummary(
                    id = id,
                    facing = when (c.get(CC.LENS_FACING)) {
                        CC.LENS_FACING_FRONT -> "Front"
                        CC.LENS_FACING_BACK -> "Back"
                        else -> "External"
                    },
                    hasFlash = c.get(CC.FLASH_INFO_AVAILABLE) == true,
                    hasAutofocus = (c.get(CC.CONTROL_AF_AVAILABLE_MODES)?.size ?: 0) > 1,
                    supportsRaw = c.get(CC.REQUEST_AVAILABLE_CAPABILITIES)
                        ?.contains(CC.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true,
                    maxJpegMp = best?.let { it.width * it.height / 1_000_000f } ?: 0f,
                    fpsRanges = c.get(CC.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.map { "${it.lower}-${it.upper}" } ?: emptyList(),
                    videoStabilization = (c.get(CC.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.size ?: 0) > 1,
                )
            }.getOrNull()
        }
        return DeviceReport(cams, mi.totalMem / 1048576, mi.availMem / 1048576,
            Runtime.getRuntime().availableProcessors(), am.isLowRamDevice, Build.VERSION.SDK_INT)
    }
}
