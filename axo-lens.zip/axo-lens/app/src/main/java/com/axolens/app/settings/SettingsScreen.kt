package com.axolens.app.settings

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolens.app.Prefs
import com.axolens.app.device.DeviceAnalyzer
import com.axolens.app.device.PerformanceProfile
import com.axolens.app.ui.AxoYellow

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(sub, color = Color.Gray, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Header(t: String) {
    Spacer(Modifier.height(18.dp))
    Text(t, color = AxoYellow, fontSize = 13.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun SettingsScreen(profile: PerformanceProfile) {
    val ctx = LocalContext.current
    val report = remember { runCatching { DeviceAnalyzer.analyze(ctx) }.getOrNull() }
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)

        Header("PHOTO QUALITY")
        SwitchRow("AXO Enhance on every photo", "Removes haze, lifts shadows, fixes colour, sharpens. Turn off for untouched camera JPEGs.",
            Prefs.autoEnhance.value) { Prefs.autoEnhance.value = it }
        Text("Enhance strength ${(Prefs.strength.value * 100).toInt()}%", color = Color.White, fontSize = 14.sp)
        Slider(Prefs.strength.value, { Prefs.strength.value = it }, valueRange = 0.3f..1.2f)
        SwitchRow("Keep original too", "Saves the untouched photo too, so you can compare original vs enhanced in Gallery. Turn off later to save space.",
            Prefs.keepOriginal.value) { Prefs.keepOriginal.value = it }

        Header("CAMERA")
        SwitchRow("Grid lines", "Rule-of-thirds grid on the preview.", Prefs.grid.value) { Prefs.grid.value = it }
        SwitchRow("16:9 photos", "Off = 4:3 (full sensor, best quality).", Prefs.ratio169.value) { Prefs.ratio169.value = it }
        SwitchRow("Haptic feedback", "Small vibration on shutter and taps.", Prefs.haptics.value) { Prefs.haptics.value = it }
        SwitchRow("Record audio in videos", "Needs microphone permission.", Prefs.audio.value) { Prefs.audio.value = it }
        Text("Tip: volume buttons work as the shutter on the camera screen.", color = Color.Gray, fontSize = 12.sp)

        Header("DEVICE OPTIMIZER")
        Text("Profile chosen automatically: ${profile.label}", color = Color.White, fontSize = 14.sp)
        if (report != null) {
            Text("RAM: ${report.totalRamMb} MB total, ${report.availRamMb} MB free\nCPU cores: ${report.cpuCores}\nAndroid SDK: ${report.sdk}",
                color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            report.cameras.forEach {
                Text("Camera ${it.id} (${it.facing}): up to %.1f MP, flash ${if (it.hasFlash) "yes" else "no"}, autofocus ${if (it.hasAutofocus) "yes" else "no"}, RAW ${if (it.supportsRaw) "yes" else "no"}, stabilization ${if (it.videoStabilization) "yes" else "no"}".format(it.maxJpegMp),
                    color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        Header("STORAGE AND PRIVACY")
        Button(onClick = {
            val n = ctx.cacheDir.listFiles()?.count { it.deleteRecursively() } ?: 0
            Toast.makeText(ctx, "Cleared $n temporary files", Toast.LENGTH_SHORT).show()
        }) { Text("Clear temporary files") }
        Text("AXO LENS has no internet permission. Photos and videos never leave your phone. The camera and microphone " +
            "are used only while you are on the camera screen. Files are saved in Pictures/AXO LENS and Movies/AXO LENS.",
            color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))

        Header("ABOUT")
        Text("AXO LENS 0.2.0 - Capture Beyond Limits.\nNot yet built: panorama, RAW/DNG, slow motion, cloud AI, neural super-resolution, " +
            "object removal, video enhancer.", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(24.dp))
    }
}
