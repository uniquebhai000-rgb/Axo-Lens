@file:Suppress("DEPRECATION")
package com.axolens.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class MediaItem(
    val uri: Uri, val isVideo: Boolean, val name: String, val dateSec: Long,
    val size: Long, val width: Int, val height: Int, val durationMs: Long,
)

object MediaRepo {
    const val FOLDER = "AXO LENS"

    fun load(ctx: Context): List<MediaItem> {
        val all = ArrayList<MediaItem>()
        all += query(ctx, false)
        all += query(ctx, true)
        return all.sortedByDescending { it.dateSec }
    }

    private fun query(ctx: Context, video: Boolean): List<MediaItem> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val proj = mutableListOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.WIDTH, MediaStore.MediaColumns.HEIGHT,
        )
        if (video) proj += MediaStore.Video.Media.DURATION
        val sel: String
        val args: Array<String>
        if (Build.VERSION.SDK_INT >= 29) {
            sel = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"; args = arrayOf("%$FOLDER%")
        } else {
            sel = "${MediaStore.MediaColumns.DATA} LIKE ?"; args = arrayOf("%/$FOLDER/%")
        }
        val res = ArrayList<MediaItem>()
        try {
            ctx.contentResolver.query(base, proj.toTypedArray(), sel, args,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    res += MediaItem(
                        uri = ContentUris.withAppendedId(base, id), isVideo = video,
                        name = c.getString(1) ?: "item", dateSec = c.getLong(2), size = c.getLong(3),
                        width = c.getInt(4), height = c.getInt(5), durationMs = if (video) c.getLong(6) else 0L,
                    )
                }
            }
        } catch (_: Exception) { }
        return res
    }
}

object MediaSaver {
    fun newName(prefix: String = "AXO"): String =
        prefix + "_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    private fun legacyPath(dir: String, fileName: String): String {
        val d = File(Environment.getExternalStoragePublicDirectory(dir), MediaRepo.FOLDER)
        d.mkdirs()
        return File(d, fileName).path
    }

    fun imageValues(name: String): ContentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/${MediaRepo.FOLDER}")
        else put(MediaStore.MediaColumns.DATA, legacyPath(Environment.DIRECTORY_PICTURES, "$name.jpg"))
    }

    fun videoValues(name: String): ContentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.mp4")
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/${MediaRepo.FOLDER}")
        else put(MediaStore.MediaColumns.DATA, legacyPath(Environment.DIRECTORY_MOVIES, "$name.mp4"))
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap, name: String, quality: Int = 95): Uri? {
        val cr = ctx.contentResolver
        val cv = imageValues(name)
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        return try {
            cr.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
            if (Build.VERSION.SDK_INT >= 29) {
                val u = ContentValues(); u.put(MediaStore.MediaColumns.IS_PENDING, 0); cr.update(uri, u, null, null)
            }
            uri
        } catch (e: Exception) { cr.delete(uri, null, null); null }
    }

    fun saveFile(ctx: Context, f: File, name: String): Uri? {
        val cr = ctx.contentResolver
        val cv = imageValues(name)
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return null
        return try {
            cr.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val u = ContentValues(); u.put(MediaStore.MediaColumns.IS_PENDING, 0); cr.update(uri, u, null, null)
            }
            uri
        } catch (e: Exception) { cr.delete(uri, null, null); null }
    }
}

object PhotoPipeline {
    /** Takes the raw camera JPEG, optionally enhances it, saves to gallery. Falls back to the original on any failure. */
    fun process(ctx: Context, tmp: File, enhance: Boolean, spec: EnhanceSpec, maxSide: Int, keepOriginal: Boolean): Uri? {
        val stamp = MediaSaver.newName("AXO")
        val name = stamp.replaceFirst("AXO_", "AXO_HD_")
        if (!enhance) return MediaSaver.saveFile(ctx, tmp, stamp)
        var saved: Uri? = null
        try {
            val bmp = Enhancer.loadBitmap(ctx, Uri.fromFile(tmp), maxSide)
            if (bmp != null) {
                val out = Enhancer.enhance(bmp, spec)
                bmp.recycle()
                saved = MediaSaver.saveBitmap(ctx, out, name, 95)
                out.recycle()
                if (saved != null && keepOriginal) MediaSaver.saveFile(ctx, tmp, name + "_orig")
            }
        } catch (e: OutOfMemoryError) {
            saved = null
        } catch (e: Exception) {
            saved = null
        }
        return saved ?: MediaSaver.saveFile(ctx, tmp, stamp)
    }
}
