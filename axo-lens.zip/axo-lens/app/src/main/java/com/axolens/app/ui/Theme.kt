package com.axolens.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AxoBlue = Color(0xFF3D7BFF)
val AxoPurple = Color(0xFF8B5CF6)
val AxoYellow = Color(0xFFFFD60A)
val AxoCard = Color(0xFF16161A)

@Composable
fun AxoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = AxoBlue, secondary = AxoPurple,
            background = Color.Black, surface = Color(0xFF111114)),
        content = content,
    )
}
