@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.axolens.app.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.GridOff
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.axolens.app.EnhanceSpec
import com.axolens.app.MediaRepo
import com.axolens.app.MediaSaver
import com.axolens.app.PhotoPipeline
import com.axolens.app.Prefs
import com.axolens.app.ShutterBus
import com.axolens.app.device.DeviceAnalyzer
import com.axolens.app.device.PerformanceProfile
import com.axolens.app.ui.AxoPurple
import com.axolens.app.ui.AxoYellow
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.pow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Mode(val label: String, val ext: Int?, val video: Boolean = false) {
    PHOTO("PHOTO", null),
    PORTRAIT("PORTRAIT", ExtensionMode.BOKEH),
    NIGHT("NIGHT", ExtensionMode.NIGHT),
    HDR("HDR", ExtensionMode.HDR),
    LANDSCAPE("LANDSCAPE", null),
    FOOD("FOOD", null),
    SCAN("SCAN", null),
    PRO("PRO", null),
    BURST("BURST", null),
    VIDEO("VIDEO", null, true),
}

private fun specFor(m: Mode): EnhanceSpec {
    val s = Prefs.strength.value
    return when (m) {
        Mode.NIGHT -> EnhanceSpec(s, 1.1f, 0.5f, 0f, 0.5f)
        Mode.HDR -> EnhanceSpec(s, 1.15f, 0.7f, 0f, 0.5f)
        Mode.LANDSCAPE -> EnhanceSpec(s, 1.28f, 0.9f, 0f, 0.46f)
        Mode.FOOD -> EnhanceSpec(s, 1.22f, 0.6f, 0.05f, 0.5f)
        Mode.PORTRAIT -> EnhanceSpec(s * 0.8f, 1.05f, 0.4f, 0.02f, 0.48f)
        Mode.SCAN -> EnhanceSpec(1f, 1f, 1f, 0f, 0.5f, true)
        else -> EnhanceSpec(s, 1.12f, 0.65f, 0f, 0.46f)
    }
}

private fun qLabel(q: Quality): String = when (q) {
    Quality.UHD -> "4K"
    Quality.FHD -> "1080p"
    Quality.HD -> "720p"
    Quality.SD -> "480p"
    else -> "Auto"
}

private suspend fun Context.cameraProvider(): ProcessCameraProvider = suspendCoroutine { c ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ c.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

private suspend fun Context.extManager(p: ProcessCameraProvider): ExtensionsManager? = suspendCoroutine { c ->
    try {
        val f = ExtensionsManager.getInstanceAsync(this, p)
        f.addListener({ c.resume(runCatching { f.get() }.getOrNull()) }, ContextCompat.getMainExecutor(this))
    } catch (e: Exception) { c.resume(null) }
}

private suspend fun ImageCapture.takeToFile(ctx: Context, f: File): Boolean = suspendCoroutine { c ->
    takePicture(ImageCapture.OutputFileOptions.Builder(f).build(), ContextCompat.getMainExecutor(ctx),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) { c.resume(true) }
            override fun onError(exception: ImageCaptureException) { c.resume(false) }
        })
}

private suspend fun ImageCapture.takeToMediaStore(ctx: Context, name: String): Uri? = suspendCoroutine { c ->
    val opts = ImageCapture.OutputFileOptions.Builder(
        ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, MediaSaver.imageValues(name)).build()
    takePicture(opts, ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageSavedCallback {
        override fun onImageSaved(output: ImageCapture.OutputFileResults) { c.resume(output.savedUri) }
        override fun onError(exception: ImageCaptureException) { c.resume(null) }
    })
}

@OptIn(ExperimentalCamera2Interop::class)
private fun applyManual(cam: Camera, manual: Boolean, iso: Int, ns: Long, awb: Int) {
    val c2 = Camera2CameraControl.from(cam.cameraControl)
    val b = CaptureRequestOptions.Builder()
    b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, awb)
    if (manual) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, ns)
    }
    c2.setCaptureRequestOptions(b.build())
}

@OptIn(ExperimentalCamera2Interop::class)
private fun clearManual(cam: Camera) {
    Camera2CameraControl.from(cam.cameraControl).clearCaptureRequestOptions()
}

@SuppressLint("MissingPermission")
@Composable
fun CameraScreen(
    profile: PerformanceProfile,
    onGallery: () -> Unit,
    onSettings: () -> Unit,
    onStudio: () -> Unit,
) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()

    val needed = remember {
        buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT <= 28) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    }
    fun hasAll() = needed.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    var granted by remember { mutableStateOf(hasAll()) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasAll() }
    LaunchedEffect(Unit) { if (!granted) permLauncher.launch(needed.toTypedArray()) }
    var audioGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val audioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        audioGranted = it; Prefs.audio.value = it
    }

    if (!granted) {
        Column(Modifier.fillMaxSize().background(Color.Black).padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("AXO LENS needs camera access to take photos and videos. Nothing is recorded or uploaded without your action.",
                color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { permLauncher.launch(needed.toTypedArray()) }) { Text("Grant access") }
        }
        return
    }

    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    var providerRef by remember { mutableStateOf<ProcessCameraProvider?>(null) }
    var mode by remember { mutableStateOf(Mode.PHOTO) }
    var facing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var torch by remember { mutableStateOf(false) }
    var timer by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var ev by remember { mutableFloatStateOf(0f) }
    var showTune by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var focusPt by remember { mutableStateOf<Offset?>(null) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var vq by remember { mutableStateOf(Quality.FHD) }
    var vqOptions by remember { mutableStateOf<List<Quality>>(emptyList()) }
    var recording by remember { mutableStateOf<Recording?>(null) }
    var paused by remember { mutableStateOf(false) }
    var recSecs by remember { mutableIntStateOf(0) }
    // Pro
    var proManual by remember { mutableStateOf(false) }
    var iso by remember { mutableFloatStateOf(200f) }
    var expT by remember { mutableFloatStateOf(0.55f) }
    var awb by remember { mutableIntStateOf(CaptureRequest.CONTROL_AWB_MODE_AUTO) }
    val pro = remember(facing) { DeviceAnalyzer.proRanges(ctx, facing) }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun tick() { if (Prefs.haptics.value) view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
    fun expNs(): Long {
        val p = pro ?: return 10_000_000L
        val lo = p.expMinNs.coerceAtLeast(100_000L).toDouble()
        val hi = minOf(p.expMaxNs, 500_000_000L).toDouble().coerceAtLeast(lo)
        return (lo * (hi / lo).pow(expT.toDouble())).toLong()
    }

    LaunchedEffect(Unit) {
        lastUri = withContext(Dispatchers.IO) { runCatching { MediaRepo.load(ctx).firstOrNull()?.uri }.getOrNull() }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching { recording?.stop() }
            runCatching { providerRef?.unbindAll() }
        }
    }

    LaunchedEffect(facing, mode, vq, Prefs.ratio169.value) {
        val provider = ctx.cameraProvider()
        providerRef = provider
        val m = mode
        var selector = CameraSelector.Builder().requireLensFacing(facing).build()
        if (!provider.hasCamera(selector)) {
            if (facing != CameraSelector.LENS_FACING_BACK) facing = CameraSelector.LENS_FACING_BACK
            return@LaunchedEffect
        }
        notice = null
        val extId = m.ext
        if (extId != null) {
            val em = ctx.extManager(provider)
            if (em != null && em.isExtensionAvailable(selector, extId)) {
                selector = em.getExtensionEnabledCameraSelector(selector, extId)
            } else {
                notice = "${m.label.lowercase().replaceFirstChar { it.uppercase() }}: hardware mode not on this phone. Using AXO software enhance."
            }
        }
        val strat = if (Prefs.ratio169.value) AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY
                    else AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
        val preview = Preview.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(strat).build())
            .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        try {
            provider.unbindAll()
            if (m.video) {
                val info = selector.filter(provider.availableCameraInfos).firstOrNull()
                vqOptions = if (info != null) QualitySelector.getSupportedQualities(info) else emptyList()
                val qs = QualitySelector.fromOrderedList(
                    listOf(vq, Quality.FHD, Quality.HD, Quality.SD), FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                val vc = VideoCapture.withOutput(Recorder.Builder().setQualitySelector(qs).build())
                camera = provider.bindToLifecycle(owner, selector, preview, vc)
                videoCapture = vc; imageCapture = null
            } else {
                val rs = ResolutionSelector.Builder().setAspectRatioStrategy(strat).also {
                    if (extId == null) it.setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                }.build()
                val cap = ImageCapture.Builder()
                    .setResolutionSelector(rs)
                    .setCaptureMode(if (profile.maxQuality) ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                                    else ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setJpegQuality(profile.jpegQuality)
                    .setFlashMode(flash)
                    .build()
                camera = provider.bindToLifecycle(owner, selector, preview, cap)
                imageCapture = cap; videoCapture = null
            }
            zoom = 1f; ev = 0f
        } catch (e: Exception) {
            toast("Camera unavailable: ${e.message}")
        }
    }
    val hasFlash = camera?.cameraInfo?.hasFlashUnit() == true
    LaunchedEffect(flash, imageCapture) { imageCapture?.flashMode = flash }
    LaunchedEffect(camera, torch) { camera?.cameraControl?.enableTorch(torch && hasFlash) }
    LaunchedEffect(camera, mode, proManual, iso, expT, awb) {
        val cam = camera ?: return@LaunchedEffect
        try {
            if (mode == Mode.PRO) applyManual(cam, proManual && pro != null, iso.toInt(), expNs(), awb)
            else clearManual(cam)
        } catch (_: Exception) { }
    }
    LaunchedEffect(focusPt) { if (focusPt != null) { delay(900); focusPt = null } }

    val zoomState = camera?.cameraInfo?.zoomState?.value
    val evRange = camera?.cameraInfo?.exposureState?.exposureCompensationRange
    val evStep = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f

    fun setZoom(z: Float) {
        val zs = camera?.cameraInfo?.zoomState?.value ?: return
        zoom = z.coerceIn(zs.minZoomRatio, minOf(zs.maxZoomRatio, 10f))
        camera?.cameraControl?.setZoomRatio(zoom)
    }

    suspend fun capturePhoto() {
        val cap = imageCapture ?: return
        val m = mode
        busy = true
        try {
            if (m == Mode.BURST) {
                var n = 0
                for (i in 1..6) {
                    val u = cap.takeToMediaStore(ctx, MediaSaver.newName("AXO_burst"))
                    if (u != null) { lastUri = u; n++ }
                }
                toast("Burst saved: $n photos")
            } else {
                val tmp = File(ctx.cacheDir, "cap_${System.nanoTime()}.jpg")
                if (!cap.takeToFile(ctx, tmp)) { toast("Capture failed. Try again."); return }
                val enhance = m != Mode.PRO && (Prefs.autoEnhance.value || m == Mode.SCAN)
                val uri = withContext(Dispatchers.Default) {
                    PhotoPipeline.process(ctx, tmp, enhance, specFor(m), profile.maxSide, Prefs.keepOriginal.value)
                }
                tmp.delete()
                if (uri != null) { lastUri = uri; toast(if (enhance) "Saved (AXO enhanced)" else "Saved") }
                else toast("Could not save. Check storage space.")
            }
        } finally { busy = false }
    }

    fun toggleRecord() {
        val rec = recording
        if (rec != null) { rec.stop(); return }
        val vc = videoCapture ?: return
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(MediaSaver.videoValues(MediaSaver.newName("AXO_vid"))).build()
        var pr = vc.output.prepareRecording(ctx, opts)
        if (Prefs.audio.value && audioGranted) pr = pr.withAudioEnabled()
        recording = pr.start(ContextCompat.getMainExecutor(ctx)) { ev2 ->
            when (ev2) {
                is VideoRecordEvent.Status -> recSecs = (ev2.recordingStats.recordedDurationNanos / 1_000_000_000L).toInt()
                is VideoRecordEvent.Pause -> paused = true
                is VideoRecordEvent.Resume -> paused = false
                is VideoRecordEvent.Finalize -> {
                    recording = null; paused = false; recSecs = 0
                    if (ev2.hasError()) toast("Recording failed (code ${ev2.error})")
                    else { lastUri = ev2.outputResults.outputUri; toast("Video saved") }
                }
                else -> {}
            }
            Unit
        }
    }

    fun handleShutter() {
        if (mode.video) { tick(); toggleRecord(); return }
        if (busy || countdown > 0) return
        tick()
        scope.launch {
            if (timer > 0) { for (i in timer downTo 1) { countdown = i; delay(1000) }; countdown = 0 }
            capturePhoto()
        }
    }

    val shutterAction = rememberUpdatedState(newValue = { handleShutter() })
    DisposableEffect(Unit) {
        ShutterBus.action = { shutterAction.value() }
        onDispose { ShutterBus.action = null }
    }

    val ratio = if (mode.video || Prefs.ratio169.value) 9f / 16f else 3f / 4f
    val isRec = recording != null

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.align(Alignment.TopCenter).padding(top = 56.dp).fillMaxWidth().aspectRatio(ratio)) {
            AndroidView({ previewView }, Modifier.fillMaxSize()
                .pointerInput(Unit) { detectTransformGestures { _, _, z, _ -> if (z != 1f) setZoom(zoom * z) } }
                .pointerInput(Unit) {
                    detectTapGestures { p ->
                        val pt = previewView.meteringPointFactory.createPoint(p.x, p.y)
                        camera?.cameraControl?.startFocusAndMetering(
                            FocusMeteringAction.Builder(pt).setAutoCancelDuration(3, TimeUnit.SECONDS).build())
                        focusPt = p
                        tick()
                    }
                })
            if (Prefs.grid.value) Canvas(Modifier.fillMaxSize()) {
                val c = Color(0x66FFFFFF)
                drawLine(c, Offset(size.width / 3, 0f), Offset(size.width / 3, size.height), 1f)
                drawLine(c, Offset(size.width * 2 / 3, 0f), Offset(size.width * 2 / 3, size.height), 1f)
                drawLine(c, Offset(0f, size.height / 3), Offset(size.width, size.height / 3), 1f)
                drawLine(c, Offset(0f, size.height * 2 / 3), Offset(size.width, size.height * 2 / 3), 1f)
            }
            focusPt?.let { p ->
                Box(Modifier.offset { IntOffset((p.x - 36.dp.toPx()).toInt(), (p.y - 36.dp.toPx()).toInt()) }
                    .size(72.dp).border(1.5.dp, AxoYellow, CircleShape))
            }
            if (countdown > 0) Text("$countdown", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Light,
                modifier = Modifier.align(Alignment.Center))
            if (isRec) Row(Modifier.align(Alignment.TopCenter).padding(8.dp)
                .background(Color(0x99000000), RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (paused) Color.Gray else Color.Red))
                Spacer(Modifier.size(6.dp))
                Text("%02d:%02d".format(recSecs / 60, recSecs % 60), color = Color.White)
            }
        }

        // Top bar
        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().height(52.dp).padding(horizontal = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onStudio) { Icon(Icons.Default.AutoAwesome, "AI Studio", tint = Color.White) }
            if (hasFlash && !mode.video) IconButton(onClick = {
                flash = when (flash) {
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                    else -> ImageCapture.FLASH_MODE_AUTO
                }
            }) {
                Icon(when (flash) {
                    ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                    ImageCapture.FLASH_MODE_OFF -> Icons.Default.FlashOff
                    else -> Icons.Default.FlashAuto
                }, "Flash", tint = if (flash == ImageCapture.FLASH_MODE_OFF) Color.White else AxoYellow)
            }
            if (hasFlash) IconButton(onClick = { torch = !torch; tick() }) {
                Icon(Icons.Default.Lightbulb, "Torch", tint = if (torch) AxoYellow else Color.White)
            }
            if (!mode.video) IconButton(onClick = { timer = when (timer) { 0 -> 3; 3 -> 5; 5 -> 10; else -> 0 } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Timer, "Timer", tint = if (timer > 0) AxoYellow else Color.White)
                    if (timer > 0) Text("${timer}s", color = AxoYellow, fontSize = 12.sp)
                }
            }
            IconButton(onClick = { Prefs.grid.value = !Prefs.grid.value }) {
                Icon(if (Prefs.grid.value) Icons.Default.GridOn else Icons.Default.GridOff, "Grid",
                    tint = if (Prefs.grid.value) AxoYellow else Color.White)
            }
            if (!mode.video && !isRec) Text(if (Prefs.ratio169.value) "16:9" else "4:3",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { Prefs.ratio169.value = !Prefs.ratio169.value }.padding(8.dp))
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
        }

        // Bottom controls
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            .background(if (ratio < 0.6f) Color(0x88000000) else Color.Black)
            .navigationBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            notice?.let { Text(it, color = AxoYellow, fontSize = 11.sp) }
            if (showTune && evRange != null && evRange.upper > evRange.lower && evStep > 0f) {
                Text("Brightness (EV) %+.1f".format(ev * evStep), color = Color.White, fontSize = 12.sp)
                Slider(value = ev, onValueChange = { ev = it; camera?.cameraControl?.setExposureCompensationIndex(it.toInt()) },
                    valueRange = evRange.lower.toFloat()..evRange.upper.toFloat())
            }
            if (mode == Mode.PRO) {
                if (pro == null) Text("This phone does not allow manual ISO/shutter. Showing auto controls only.",
                    color = Color.LightGray, fontSize = 11.sp)
                else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Manual ISO + shutter", color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.size(8.dp))
                        Switch(checked = proManual, onCheckedChange = { proManual = it })
                    }
                    if (proManual) {
                        Text("ISO ${iso.toInt()}", color = Color.White, fontSize = 12.sp)
                        Slider(value = iso, onValueChange = { iso = it }, valueRange = pro.isoMin.toFloat()..pro.isoMax.toFloat())
                        val ns = expNs()
                        Text(if (ns >= 100_000_000L) "Shutter %.2fs".format(ns / 1e9) else "Shutter 1/${(1e9 / ns).toInt()}",
                            color = Color.White, fontSize = 12.sp)
                        Slider(value = expT, onValueChange = { expT = it })
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("Auto WB" to 1, "Daylight" to 5, "Cloudy" to 6, "Tungsten" to 2, "Fluor." to 3)) { (n, v) ->
                        Chip(n, awb == v) { awb = v }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (zoomState != null) for (z in listOf(1f, 2f, 5f)) {
                    if (z >= zoomState.minZoomRatio && z <= zoomState.maxZoomRatio) Chip("${z.toInt()}x", kotlin.math.abs(zoom - z) < 0.15f) { setZoom(z) }
                }
                Chip("%.1fx".format(zoom), false) { }
                Chip("EV", showTune) { showTune = !showTune }
                if (mode.video) Chip(if (Prefs.audio.value && audioGranted) "Mic on" else "Mic off", Prefs.audio.value && audioGranted) {
                    if (!audioGranted) audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    else Prefs.audio.value = !Prefs.audio.value
                }
            }
            if (mode.video && !isRec && vqOptions.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(vqOptions) { q -> Chip(qLabel(q), vq == q) { vq = q } }
                }
            }
            Spacer(Modifier.height(6.dp))
            if (!isRec) LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                items(Mode.values().toList()) { m ->
                    Text(m.label, color = if (m == mode) AxoYellow else Color.White,
                        fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { if (!busy) { mode = m; tick() } }.padding(vertical = 6.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF222226)).clickable { onGallery() }) {
                    if (lastUri != null) AsyncImage(lastUri, "Gallery", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                Shutter(mode.video, isRec, busy) { handleShutter() }
                if (isRec) IconButton(onClick = {
                    val r = recording
                    if (r != null) { if (paused) r.resume() else r.pause() }
                }, Modifier.size(52.dp)) {
                    Icon(if (paused) Icons.Default.PlayArrow else Icons.Default.Pause, "Pause", tint = Color.White)
                }
                else IconButton(onClick = {
                    facing = if (facing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT
                             else CameraSelector.LENS_FACING_BACK
                    torch = false
                }, Modifier.size(52.dp)) { Icon(Icons.Default.FlipCameraAndroid, "Switch camera", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(text, color = if (selected) Color.Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) AxoYellow else Color(0xFF2A2A2E))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp))
}

@Composable
private fun Shutter(video: Boolean, recording: Boolean, busy: Boolean, onClick: () -> Unit) {
    val inner by animateDpAsState(if (recording) 28.dp else 60.dp, label = "shutter")
    val shape = if (recording) RoundedCornerShape(8.dp) else CircleShape
    Box(Modifier.size(80.dp).border(4.dp, Color.White, CircleShape).padding(6.dp).clip(CircleShape)
        .clickable(enabled = !busy, onClick = onClick), contentAlignment = Alignment.Center) {
        Box(Modifier.size(inner).clip(shape).background(if (busy) AxoPurple else if (video) Color.Red else Color.White))
    }
}
