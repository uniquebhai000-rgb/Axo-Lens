package com.axolens.app.camera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.view.HapticFeedbackConstants
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.axolens.app.device.PerformanceProfile
import com.axolens.app.ui.AxoPurple
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

private suspend fun Context.cameraProvider(): ProcessCameraProvider = suspendCoroutine { c ->
    val f = ProcessCameraProvider.getInstance(this)
    f.addListener({ c.resume(f.get()) }, ContextCompat.getMainExecutor(this))
}

@Composable
fun CameraScreen(profile: PerformanceProfile) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(Modifier.fillMaxSize().background(Color.Black).padding(32.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("AXO LENS needs camera access to take photos. Nothing is recorded or uploaded without your action.",
                color = Color.White)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Grant camera access") }
        }
        return
    }

    val previewView = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    var facing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var flash by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_AUTO) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var ev by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(facing) {
        val provider = ctx.cameraProvider()
        val selector = CameraSelector.Builder().requireLensFacing(facing).build()
        if (!provider.hasCamera(selector)) {
            facing = CameraSelector.LENS_FACING_BACK
            return@LaunchedEffect
        }
        val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
        val capture = ImageCapture.Builder()
            .setCaptureMode(
                if (profile.maxQuality) ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                else ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
            )
            .setJpegQuality(profile.jpegQuality)
            .setFlashMode(flash)
            .build()
        try {
            provider.unbindAll()
            camera = provider.bindToLifecycle(owner, selector, preview, capture)
            imageCapture = capture
            zoom = 1f
            ev = 0f
        } catch (e: Exception) {
            Toast.makeText(ctx, "Camera unavailable: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    LaunchedEffect(flash) { imageCapture?.flashMode = flash }

    val zoomState = camera?.cameraInfo?.zoomState?.value
    val evRange = camera?.cameraInfo?.exposureState?.exposureCompensationRange
    val evStep = camera?.cameraInfo?.exposureState?.exposureCompensationStep?.toFloat() ?: 0f
    val hasFlash = camera?.cameraInfo?.hasFlashUnit() == true

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ previewView }, Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures { p ->
                val point = previewView.meteringPointFactory.createPoint(p.x, p.y)
                camera?.cameraControl?.startFocusAndMetering(
                    FocusMeteringAction.Builder(point).setAutoCancelDuration(3, TimeUnit.SECONDS).build())
                view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
        })

        Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("AXO LENS", color = Color.White, style = MaterialTheme.typography.titleMedium)
            if (hasFlash) IconButton(onClick = {
                flash = when (flash) {
                    ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                    ImageCapture.FLASH_MODE_ON -> ImageCapture.FLASH_MODE_OFF
                    else -> ImageCapture.FLASH_MODE_AUTO
                }
            }) {
                Icon(
                    when (flash) {
                        ImageCapture.FLASH_MODE_ON -> Icons.Default.FlashOn
                        ImageCapture.FLASH_MODE_OFF -> Icons.Default.FlashOff
                        else -> Icons.Default.FlashAuto
                    }, "Flash", tint = Color.White)
            }
        }

        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            if (zoomState != null && zoomState.maxZoomRatio > zoomState.minZoomRatio) {
                Text("%.1fx".format(zoom), color = Color.White)
                Slider(value = zoom, onValueChange = { zoom = it; camera?.cameraControl?.setZoomRatio(it) },
                    valueRange = zoomState.minZoomRatio..minOf(zoomState.maxZoomRatio, 10f))
            }
            if (evRange != null && evRange.upper > evRange.lower && evStep > 0f) {
                Text("EV %+.1f".format(ev * evStep), color = Color.White)
                Slider(value = ev,
                    onValueChange = { ev = it; camera?.cameraControl?.setExposureCompensationIndex(it.toInt()) },
                    valueRange = evRange.lower.toFloat()..evRange.upper.toFloat())
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.size(48.dp))
                Box(Modifier.size(78.dp).clip(CircleShape).border(4.dp, Color.White, CircleShape).padding(7.dp)
                    .clip(CircleShape).background(if (busy) AxoPurple else Color.White)
                    .pointerInput(busy) {
                        detectTapGestures {
                            if (busy) return@detectTapGestures
                            val cap = imageCapture ?: return@detectTapGestures
                            busy = true
                            view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                            takePhoto(ctx, cap) { busy = false }
                        }
                    })
                IconButton(onClick = {
                    facing = if (facing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT
                    else CameraSelector.LENS_FACING_BACK
                }, Modifier.size(48.dp)) { Icon(Icons.Default.FlipCameraAndroid, "Switch camera", tint = Color.White) }
            }
        }
    }
}

private fun takePhoto(ctx: Context, capture: ImageCapture, done: () -> Unit) {
    val name = "AXO_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AXO LENS")
    }
    val opts = ImageCapture.OutputFileOptions.Builder(
        ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
    capture.takePicture(opts, ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageSavedCallback {
        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
            Toast.makeText(ctx, "Saved to Pictures/AXO LENS", Toast.LENGTH_SHORT).show()
            done()
        }
        override fun onError(e: ImageCaptureException) {
            Toast.makeText(ctx, "Capture failed: ${e.message}", Toast.LENGTH_LONG).show()
            done()
        }
    })
}
