package com.axolens.app.studio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import com.axolens.app.EnhanceSpec
import com.axolens.app.Enhancer
import com.axolens.app.Prefs
import kotlin.math.hypot

data class EditParams(
    val bright: Float = 0f, val contrast: Float = 0f, val sat: Float = 0f, val warm: Float = 0f,
    val vignette: Float = 0f, val rot: Int = 0, val flip: Boolean = false, val enhance: Boolean = false,
    val filter: String = "Original", val fK: Float = 1f,
)

/** order: brightness, contrast, saturation, warmth, vignette */
val FILTERS: LinkedHashMap<String, FloatArray> = linkedMapOf(
    "Original" to floatArrayOf(0f, 0f, 0f, 0f, 0f),
    "Vivid" to floatArrayOf(0f, 12f, 30f, 0f, 0f),
    "Warm" to floatArrayOf(0f, 0f, 10f, 30f, 0f),
    "Cool" to floatArrayOf(0f, 0f, 0f, -30f, 0f),
    "B&W" to floatArrayOf(0f, 18f, -100f, 0f, 0f),
    "Vintage" to floatArrayOf(0f, -5f, -25f, 25f, 35f),
    "Cinematic" to floatArrayOf(-5f, 22f, -12f, -10f, 28f),
    "Mood" to floatArrayOf(-12f, 25f, -20f, -5f, 40f),
)

fun effective(p: EditParams): FloatArray {
    val f = FILTERS[p.filter] ?: FILTERS.getValue("Original")
    return floatArrayOf(
        p.bright + f[0] * p.fK, p.contrast + f[1] * p.fK, p.sat + f[2] * p.fK, p.warm + f[3] * p.fK, p.vignette + f[4] * p.fK,
    )
}

fun buildMatrix(e: FloatArray): ColorMatrix {
    val m = ColorMatrix()
    m.setSaturation((1f + e[2] / 100f).coerceAtLeast(0f))
    val w = e[3] / 100f * 0.18f
    m.postConcat(ColorMatrix(floatArrayOf(
        1f + w, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1f - w, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
    val c = 1f + e[1] / 100f
    val t = 128f * (1f - c) + e[0] * 1.5f
    m.postConcat(ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    return m
}

fun transformBitmap(b: Bitmap, rot: Int, flip: Boolean): Bitmap {
    if (rot % 4 == 0 && !flip) return b
    val m = Matrix()
    if (flip) m.postScale(-1f, 1f)
    m.postRotate(90f * (rot % 4))
    return Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
}

fun renderFinal(src: Bitmap, p: EditParams): Bitmap {
    val base = if (p.enhance) Enhancer.enhance(src, EnhanceSpec(Prefs.strength.value)) else src
    val t = transformBitmap(base, p.rot, p.flip)
    val e = effective(p)
    val out = Bitmap.createBitmap(t.width, t.height, Bitmap.Config.ARGB_8888)
    val cv = Canvas(out)
    val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    paint.colorFilter = ColorMatrixColorFilter(buildMatrix(e))
    cv.drawBitmap(t, 0f, 0f, paint)
    if (e[4] > 0f) {
        val w = t.width.toFloat(); val h = t.height.toFloat()
        val a = (e[4].coerceAtMost(100f) / 100f * 200f).toInt()
        val vp = Paint()
        vp.shader = RadialGradient(w / 2f, h / 2f, hypot(w / 2f, h / 2f),
            intArrayOf(0, 0, Color.argb(a, 0, 0, 0)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w, h, vp)
    }
    if (t !== base) t.recycle()
    if (base !== src) base.recycle()
    return out
}
